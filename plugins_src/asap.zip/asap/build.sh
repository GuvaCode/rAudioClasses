#!/bin/bash
# build ASAP for linux_64
cd asap
make clean 
make 
cp libasap.so ../../dll_libs/x86_64-linux

# build ASAP for windows_64
make clean 
make OS=Windows_NT CC=x86_64-w64-mingw32-gcc AR=x86_64-w64-mingw32-ar 
mv libasap.so libasap.dll
cp libasap.dll ../../dll_libs/x86_64-win64
make clean 
cd ..
