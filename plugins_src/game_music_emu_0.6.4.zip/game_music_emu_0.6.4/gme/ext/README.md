# emu2413

A YM2413 emulator written in C by Mitsutaka Okazaki.

This is the version 0.61, tweaked by Chrosipher Snowhill (@kode54).

If you looking latest version of this module, please visit this repository:
https://github.com/digital-sound-antiques/emu2413
