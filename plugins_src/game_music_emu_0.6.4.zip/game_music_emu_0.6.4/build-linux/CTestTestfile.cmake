# CMake generated Testfile for 
# Source directory: /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4
# Build directory: /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/build-linux
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("gme")
subdirs("player")
subdirs("demo")
