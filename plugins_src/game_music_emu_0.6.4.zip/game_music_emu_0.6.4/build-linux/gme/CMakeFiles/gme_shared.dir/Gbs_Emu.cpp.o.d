gme/CMakeFiles/gme_shared.dir/Gbs_Emu.cpp.o: \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/Gbs_Emu.cpp \
 /usr/include/stdc-predef.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/Gbs_Emu.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/Classic_Emu.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/blargg_common.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/blargg_config.h \
 /usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h \
 /usr/include/c++/13/stdlib.h /usr/include/c++/13/cstdlib \
 /usr/include/x86_64-linux-gnu/c++/13/bits/c++config.h \
 /usr/include/x86_64-linux-gnu/c++/13/bits/os_defines.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/x86_64-linux-gnu/bits/wordsize.h \
 /usr/include/x86_64-linux-gnu/bits/timesize.h \
 /usr/include/x86_64-linux-gnu/sys/cdefs.h \
 /usr/include/x86_64-linux-gnu/bits/long-double.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
 /usr/include/x86_64-linux-gnu/c++/13/bits/cpu_defines.h \
 /usr/include/stdlib.h \
 /usr/include/x86_64-linux-gnu/bits/libc-header-start.h \
 /usr/include/x86_64-linux-gnu/bits/waitflags.h \
 /usr/include/x86_64-linux-gnu/bits/waitstatus.h \
 /usr/include/x86_64-linux-gnu/bits/floatn.h \
 /usr/include/x86_64-linux-gnu/bits/floatn-common.h \
 /usr/include/x86_64-linux-gnu/bits/types/locale_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/x86_64-linux-gnu/sys/types.h \
 /usr/include/x86_64-linux-gnu/bits/types.h \
 /usr/include/x86_64-linux-gnu/bits/typesizes.h \
 /usr/include/x86_64-linux-gnu/bits/time64.h \
 /usr/include/x86_64-linux-gnu/bits/types/clock_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/clockid_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/time_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/timer_t.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/x86_64-linux-gnu/bits/endian.h \
 /usr/include/x86_64-linux-gnu/bits/endianness.h \
 /usr/include/x86_64-linux-gnu/bits/byteswap.h \
 /usr/include/x86_64-linux-gnu/bits/uintn-identity.h \
 /usr/include/x86_64-linux-gnu/sys/select.h \
 /usr/include/x86_64-linux-gnu/bits/select.h \
 /usr/include/x86_64-linux-gnu/bits/types/sigset_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__sigset_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h \
 /usr/include/x86_64-linux-gnu/bits/pthreadtypes.h \
 /usr/include/x86_64-linux-gnu/bits/thread-shared-types.h \
 /usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h \
 /usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h \
 /usr/include/x86_64-linux-gnu/bits/struct_mutex.h \
 /usr/include/x86_64-linux-gnu/bits/struct_rwlock.h /usr/include/alloca.h \
 /usr/include/x86_64-linux-gnu/bits/stdlib-float.h \
 /usr/include/c++/13/bits/std_abs.h /usr/include/assert.h \
 /usr/lib/gcc/x86_64-linux-gnu/13/include/limits.h \
 /usr/lib/gcc/x86_64-linux-gnu/13/include/syslimits.h \
 /usr/include/limits.h /usr/include/x86_64-linux-gnu/bits/posix1_lim.h \
 /usr/include/x86_64-linux-gnu/bits/local_lim.h \
 /usr/include/linux/limits.h \
 /usr/include/x86_64-linux-gnu/bits/pthread_stack_min-dynamic.h \
 /usr/include/x86_64-linux-gnu/bits/posix2_lim.h \
 /usr/include/x86_64-linux-gnu/bits/xopen_lim.h \
 /usr/include/x86_64-linux-gnu/bits/uio_lim.h /usr/include/c++/13/new \
 /usr/include/c++/13/bits/exception.h \
 /usr/lib/gcc/x86_64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/x86_64-linux-gnu/bits/wchar.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-least.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/Blip_Buffer.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/Music_Emu.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/Gme_File.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/gme.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/Data_Reader.h \
 /usr/include/zlib.h /usr/include/zconf.h \
 /usr/lib/gcc/x86_64-linux-gnu/13/include/stdarg.h /usr/include/unistd.h \
 /usr/include/x86_64-linux-gnu/bits/posix_opt.h \
 /usr/include/x86_64-linux-gnu/bits/environments.h \
 /usr/include/x86_64-linux-gnu/bits/confname.h \
 /usr/include/x86_64-linux-gnu/bits/getopt_posix.h \
 /usr/include/x86_64-linux-gnu/bits/getopt_core.h \
 /usr/include/x86_64-linux-gnu/bits/unistd_ext.h \
 /usr/include/linux/close_range.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/M3u_Playlist.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/Gb_Apu.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/Gb_Oscs.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/Gb_Cpu.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/blargg_endian.h \
 /usr/include/string.h /usr/include/strings.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/gme/blargg_source.h
