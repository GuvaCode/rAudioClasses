# Empty compiler generated dependencies file for gme_shared.
# This may be replaced when dependencies are built.
