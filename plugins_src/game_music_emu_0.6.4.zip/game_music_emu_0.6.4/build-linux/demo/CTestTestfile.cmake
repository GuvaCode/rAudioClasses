# CMake generated Testfile for 
# Source directory: /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/demo
# Build directory: /home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/build-linux/demo
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(sanity_test_NSF "/home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/build-linux/demo/demo")
set_tests_properties(sanity_test_NSF PROPERTIES  _BACKTRACE_TRIPLES "/home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/demo/CMakeLists.txt;42;add_test;/home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/demo/CMakeLists.txt;0;")
add_test(check_proper_NSF_output "sha256sum" "-c" "/home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/build-linux/demo/checksums")
set_tests_properties(check_proper_NSF_output PROPERTIES  _BACKTRACE_TRIPLES "/home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/demo/CMakeLists.txt;44;add_test;/home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/demo/CMakeLists.txt;0;")
