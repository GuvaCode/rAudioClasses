file(REMOVE_RECURSE
  "CMakeFiles/demo.dir/Wave_Writer.cpp.o"
  "CMakeFiles/demo.dir/Wave_Writer.cpp.o.d"
  "CMakeFiles/demo.dir/basics.c.o"
  "CMakeFiles/demo.dir/basics.c.o.d"
  "demo"
  "demo.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C CXX)
  include(CMakeFiles/demo.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
