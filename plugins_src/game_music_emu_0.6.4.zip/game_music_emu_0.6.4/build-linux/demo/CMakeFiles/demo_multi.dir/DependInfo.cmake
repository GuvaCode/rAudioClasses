
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/demo/basics_multi.c" "demo/CMakeFiles/demo_multi.dir/basics_multi.c.o" "gcc" "demo/CMakeFiles/demo_multi.dir/basics_multi.c.o.d"
  "/home/vadim/Проекты/rAudioClasses/plugins_src/game_music_emu_0.6.4/demo/Wave_Writer.cpp" "demo/CMakeFiles/demo_multi.dir/Wave_Writer.cpp.o" "gcc" "demo/CMakeFiles/demo_multi.dir/Wave_Writer.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
