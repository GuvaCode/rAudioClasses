file(REMOVE_RECURSE
  "CMakeFiles/demo_multi.dir/Wave_Writer.cpp.o"
  "CMakeFiles/demo_multi.dir/Wave_Writer.cpp.o.d"
  "CMakeFiles/demo_multi.dir/basics_multi.c.o"
  "CMakeFiles/demo_multi.dir/basics_multi.c.o.d"
  "demo_multi"
  "demo_multi.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C CXX)
  include(CMakeFiles/demo_multi.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
