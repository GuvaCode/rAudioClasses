file(REMOVE_RECURSE
  "CMakeFiles/demo_mem.dir/Wave_Writer.cpp.o"
  "CMakeFiles/demo_mem.dir/Wave_Writer.cpp.o.d"
  "CMakeFiles/demo_mem.dir/basics_mem.c.o"
  "CMakeFiles/demo_mem.dir/basics_mem.c.o.d"
  "demo_mem"
  "demo_mem.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C CXX)
  include(CMakeFiles/demo_mem.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
