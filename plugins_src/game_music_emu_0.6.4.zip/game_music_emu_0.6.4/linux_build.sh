# Создайте отдельную директорию для сборки
mkdir build-linux
cd build-linux

#cmake -DGME_YM2612_EMU=MAME ..
cmake -DGME_YM2612_EMU=MAME ..
# Скомпилируйте проект
make -j$(nproc)
