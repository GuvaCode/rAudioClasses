#!/bin/sh

"${AUTOCONF:-autoconf}"
