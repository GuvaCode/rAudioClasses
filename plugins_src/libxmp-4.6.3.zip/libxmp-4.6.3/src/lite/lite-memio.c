#ifndef LIBXMP_CORE_PLAYER
#define LIBXMP_CORE_PLAYER
#endif
#include "../memio.c"
