#ifndef LIBXMP_CORE_PLAYER
#define LIBXMP_CORE_PLAYER
#endif
#include "../win32.c"
