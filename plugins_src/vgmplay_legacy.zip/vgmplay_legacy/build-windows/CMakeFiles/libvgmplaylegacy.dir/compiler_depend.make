# Empty compiler generated dependencies file for libvgmplaylegacy.
# This may be replaced when dependencies are built.
