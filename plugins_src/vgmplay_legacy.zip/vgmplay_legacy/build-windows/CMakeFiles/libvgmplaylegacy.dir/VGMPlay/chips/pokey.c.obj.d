CMakeFiles/libvgmplaylegacy.dir/VGMPlay/chips/pokey.c.obj: \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/pokey.c \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/mamedef.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/pokey.h
