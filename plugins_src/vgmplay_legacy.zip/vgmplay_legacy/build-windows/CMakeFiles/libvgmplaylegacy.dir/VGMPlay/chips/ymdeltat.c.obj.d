CMakeFiles/libvgmplaylegacy.dir/VGMPlay/chips/ymdeltat.c.obj: \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/ymdeltat.c \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/mamedef.h \
 /usr/share/mingw-w64/include/stdio.h \
 /usr/share/mingw-w64/include/corecrt_stdio_config.h \
 /usr/share/mingw-w64/include/corecrt.h \
 /usr/share/mingw-w64/include/_mingw.h \
 /usr/share/mingw-w64/include/_mingw_mac.h \
 /usr/share/mingw-w64/include/_mingw_secapi.h \
 /usr/share/mingw-w64/include/vadefs.h \
 /usr/share/mingw-w64/include/sdks/_mingw_ddk.h \
 /usr/share/mingw-w64/include/_mingw_off_t.h \
 /usr/share/mingw-w64/include/swprintf.inl \
 /usr/share/mingw-w64/include/sec_api/stdio_s.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/ymdeltat.h
