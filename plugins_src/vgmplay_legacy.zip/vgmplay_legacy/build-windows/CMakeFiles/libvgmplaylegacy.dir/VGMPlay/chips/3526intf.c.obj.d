CMakeFiles/libvgmplaylegacy.dir/VGMPlay/chips/3526intf.c.obj: \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/3526intf.c \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/mamedef.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/3526intf.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/fmopl.h
