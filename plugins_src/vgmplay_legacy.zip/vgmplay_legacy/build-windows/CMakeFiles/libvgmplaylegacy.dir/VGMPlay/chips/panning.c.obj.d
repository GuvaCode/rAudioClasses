CMakeFiles/libvgmplaylegacy.dir/VGMPlay/chips/panning.c.obj: \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/panning.c \
 /usr/share/mingw-w64/include/stdlib.h \
 /usr/share/mingw-w64/include/corecrt.h \
 /usr/share/mingw-w64/include/_mingw.h \
 /usr/share/mingw-w64/include/_mingw_mac.h \
 /usr/share/mingw-w64/include/_mingw_secapi.h \
 /usr/share/mingw-w64/include/vadefs.h \
 /usr/share/mingw-w64/include/sdks/_mingw_ddk.h \
 /usr/share/mingw-w64/include/corecrt_wstdlib.h \
 /usr/lib/gcc/x86_64-w64-mingw32/13-win32/include/limits.h \
 /usr/lib/gcc/x86_64-w64-mingw32/13-win32/include/syslimits.h \
 /usr/share/mingw-w64/include/limits.h \
 /usr/share/mingw-w64/include/crtdefs.h \
 /usr/share/mingw-w64/include/sec_api/stdlib_s.h \
 /usr/share/mingw-w64/include/malloc.h \
 /usr/lib/gcc/x86_64-w64-mingw32/13-win32/include/mm_malloc.h \
 /usr/share/mingw-w64/include/errno.h /usr/share/mingw-w64/include/math.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/panning.h
