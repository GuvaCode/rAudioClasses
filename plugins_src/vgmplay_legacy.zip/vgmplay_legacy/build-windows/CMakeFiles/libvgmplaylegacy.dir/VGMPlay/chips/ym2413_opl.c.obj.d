CMakeFiles/libvgmplaylegacy.dir/VGMPlay/chips/ym2413_opl.c.obj: \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/ym2413_opl.c \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/mamedef.h
