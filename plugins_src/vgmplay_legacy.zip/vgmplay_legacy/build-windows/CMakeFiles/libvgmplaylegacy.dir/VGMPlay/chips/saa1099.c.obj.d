CMakeFiles/libvgmplaylegacy.dir/VGMPlay/chips/saa1099.c.obj: \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/saa1099.c \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/mamedef.h \
 /usr/share/mingw-w64/include/string.h \
 /usr/share/mingw-w64/include/crtdefs.h \
 /usr/share/mingw-w64/include/corecrt.h \
 /usr/share/mingw-w64/include/_mingw.h \
 /usr/share/mingw-w64/include/_mingw_mac.h \
 /usr/share/mingw-w64/include/_mingw_secapi.h \
 /usr/share/mingw-w64/include/vadefs.h \
 /usr/share/mingw-w64/include/sdks/_mingw_ddk.h \
 /usr/share/mingw-w64/include/sec_api/string_s.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/saa1099.h
