CMakeFiles/libvgmplaylegacy.dir/VGMPlay/chips/3812intf.c.obj: \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/3812intf.c \
 /usr/lib/gcc/x86_64-w64-mingw32/13-win32/include/stddef.h \
 /usr/share/mingw-w64/include/stddef.h \
 /usr/share/mingw-w64/include/crtdefs.h \
 /usr/share/mingw-w64/include/corecrt.h \
 /usr/share/mingw-w64/include/_mingw.h \
 /usr/share/mingw-w64/include/_mingw_mac.h \
 /usr/share/mingw-w64/include/_mingw_secapi.h \
 /usr/share/mingw-w64/include/vadefs.h \
 /usr/share/mingw-w64/include/sdks/_mingw_ddk.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/mamedef.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/3812intf.h \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/adlibemu.h
