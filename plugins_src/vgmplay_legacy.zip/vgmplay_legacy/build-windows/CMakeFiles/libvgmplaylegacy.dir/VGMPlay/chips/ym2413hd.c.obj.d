CMakeFiles/libvgmplaylegacy.dir/VGMPlay/chips/ym2413hd.c.obj: \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/ym2413hd.c \
 /home/vadim/Проекты/rAudioClasses/plugins_src/vgmplay_legacy/VGMPlay/chips/ym2413hd.h
