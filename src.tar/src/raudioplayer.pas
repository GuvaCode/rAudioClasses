unit rAudioPlayer;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, libraudio,
  rAudioIntf,
  rAudioFileDetector,
  rDefaultAudioPlayer,
  rAsapAudioPlayer,
  rHivelyAudioPlayer,
  rZxTuneAudioPlayer,
  rOpenMptAudioPlayer,
  rXmpAudioplayer,
  rStSoundAudioPlayer,
  rGmeAudioPlayer,
  rVgmAudioPlayer;

type
  TModuleVisble = record
    ModuleHively: Boolean;  // todo добавить
  end;

  { TrAudioPlayer - базовый класс для всех аудиоплееров }
  TrAudioPlayer = class
  private
    procedure SetOnEnd(AValue: TEndEvent);
    procedure SetOnError(AValue: TErrorEvent);
    procedure SetOnPause(AValue: TPauseEvent);
    procedure SetOnPlay(AValue: TPlayEvent);
    procedure SetOnStop(AValue: TStopEvent);
  protected
    FVolume: Single;
    FTrackLoop: Boolean;
    FCurrentTrack: Integer;
    FCurrentFile: String;
    FTrackCount: Integer;
    FIsPlaying: Boolean;
    FIsPaused: Boolean;

    FEqBands: TEqBands;
    FEqBandsDecay: TEqBandsDecay;

    // События
    FOnPlay: TPlayEvent;
    FOnPause: TPauseEvent;
    FOnStop: TStopEvent;
    FOnEnd: TEndEvent;
    FOnError: TErrorEvent;

    // Плееры
    FDefaultPlayer  :IMusicPlayer;
    FAyFlyPlayer    :IMusicPlayer;
    FHivelyPlayer   :IMusicPlayer;
    FZxTunePlayer   :IMusicPlayer;
    FOpenMptPlayer  :IMusicPlayer;
    FXmpPlayer      :IMusicPlayer;
    FStSoundPlayer  :IMusicPlayer;
    FAsapPlayer     :IMusicPlayer;
    FSc68Player     :IMusicPlayer;
    FSidPlayer      :IMusicPlayer;
    FGMEPlayer      :IMusicPlayer;
    FVGMPlayer      :IMusicPlayer;
    FCurrentPlayer  :IMusicPlayer;
    // Тип
    FPlayerEngine: TPlayerType;

    procedure InitializePlayers;

    // Внутренние методы
    procedure PlayHandleEvent(Sender: TObject; Track: Integer);
    procedure PauseHandleEvent(Sender: TObject; Track: Integer);
    procedure StopHandleEvent(Sender: TObject; Track: Integer);
    procedure EndHandleEvent(Sender: TObject; Track: Integer; FinishedNormally: Boolean);
    procedure ErrorHandleEvent(Sender: TObject; const Msg: string);
  public
    constructor Create;
    destructor Destroy; override;

    // Основные методы (должны быть переопределены в потомках)
    procedure Play(const MusicFile: String; Track: Integer = 0);
    procedure Pause;
    procedure Resume;
    procedure Stop;

    // Громкость
    procedure SetVolume(Volume: Single);
    function GetVolume: Single;

    // Позиция
    procedure SetPosition(PositionMs: Integer);
    function GetPosition: Integer;
    function GetDuration: Integer;

    // Режим повтора
    procedure SetLoopMode(Mode: Boolean);
    function GetLoopMode: Boolean;

    // Состояние
    function IsPlaying: Boolean;
    function IsPaused: Boolean;

    // Информация о треке
    function GetCurrentTrack: Integer;
    function GetCurrentFile: String;
    function GetTrackCount: Integer;
    // Вывод TTF
    function GetEQBandsDecay: TEqBandsDecay;

    //
    function GetCurrentEngine: String;



    // События
    property OnPlay: TPlayEvent read FOnPlay write SetOnPlay;
    property OnPause: TPauseEvent read FOnPause write SetOnPause;
    property OnStop: TStopEvent read FOnStop write SetOnStop;
    property OnEnd: TEndEvent read FOnEnd write SetOnEnd;
    property OnError: TErrorEvent read FOnError write SetOnError;
  end;

implementation
uses libhvl,
     libzxtune,
     libopenmpt,
     libxmp,
     libstsoundlibrary,
     libAsap, libgme, libvgmplay;

{ TrAudioPlayer }

constructor TrAudioPlayer.Create;
begin
  inherited;
  // загружаем библиотеки
  libraudio.LoadLib_rAudio(FindLibName(libraudio.library_name));
  libhvl.LoadLib(FindLibName(libhvl.library_name));
  libzxtune.LoadZXTuneLibrary(FindLibName(libzxtune.DEFAULT_LIB_NAME));
  libopenmpt.LoadLib(FindLibName(libopenmpt.library_name));
  libxmp.LoadLib(FindLibName(libxmp.XMP_LIB_NAME));
  libstsoundlibrary.LoadLib(FindLibName(libstsoundlibrary.library_name));
  libasap.LoadASAPLibrary(FindLibName(libasap.DEFAULT_LIB_NAME));
  libgme.LoadLib(FindLibName(libgme.library_name));
  libvgmplay.LoadVGMLibrary(FindLibName(libvgmplay.VGMLIB_NAME));
  InitAudioDevice;

  // Инициализируем плееры
  InitializePlayers;
  FVolume := 1.0;
  FTrackLoop := True;
  FCurrentTrack := -1;
  FIsPlaying := False;
  FIsPaused := False;
  FPlayerEngine := ptUnknown;
end;

destructor TrAudioPlayer.Destroy;
begin
  Stop;
  inherited;
end;

procedure TrAudioPlayer.Play(const MusicFile: String; Track: Integer);

begin
  FPlayerEngine := DetectAudioFileType(MusicFile);

  FCurrentPlayer.Stop;
  case FPlayerEngine of
    ptUnknown .. ptDefault: FCurrentPlayer := FDefaultPlayer; // По умолчанию
    ptZxTune:  FCurrentPlayer := FZxTunePlayer;  // ZXtune
    ptHively:  FCurrentPlayer := FHivelyPlayer;
    ptOpenMPT: FCurrentPlayer := FOpenMptPlayer;
    ptXmp:     FCurrentPlayer := FXmpPlayer;
    ptStSound: FCurrentPlayer := FStSoundPlayer;
    ptASAP:    FCurrentPlayer := FAsapPlayer;
    ptGME:     FCurrentPlayer := FGMEPlayer;
    ptVGM:     FCUrrentPlayer := FGMEPlayer;
  end;

  if Assigned(FCurrentPlayer) then
  begin
    // запускаем воспроизведение
    FCurrentPlayer.Play(MusicFile, Track);
    // устанавливаем режим повтора
    FCurrentPlayer.SetLoopMode(FTrackLoop);
    FIsPlaying := True;
    FIsPaused := False;
    FCurrentFile := MusicFile;
    FCurrentTrack := Track;
  end;
end;

procedure TrAudioPlayer.Pause;
begin
  if Assigned(FCurrentPlayer) then
  begin
    FCurrentPlayer.Pause;
    FIsPlaying := False;
    FIsPaused := True;
  end;
end;

procedure TrAudioPlayer.Resume;
begin
  if Assigned(FCurrentPlayer) then
  begin
    if FIsPaused then
    begin
      FCurrentPlayer.Resume;
      FIsPlaying := True;
      FIsPaused := False;
    end;
  end;
end;

procedure TrAudioPlayer.Stop;
begin
  if Assigned(FCurrentPlayer) then
  begin
    FCurrentPlayer.Stop;
    FIsPlaying := False;
    FIsPaused := False;
  end;
end;

procedure TrAudioPlayer.SetOnEnd(AValue: TEndEvent);
begin
  if FOnEnd=AValue then Exit;
  FOnEnd:=AValue;
end;

procedure TrAudioPlayer.SetOnError(AValue: TErrorEvent);
begin
  if FOnError=AValue then Exit;
  FOnError:=AValue;
end;

procedure TrAudioPlayer.SetOnPause(AValue: TPauseEvent);
begin
  if FOnPause=AValue then Exit;
  FOnPause:=AValue;
end;

procedure TrAudioPlayer.SetOnPlay(AValue: TPlayEvent);
begin
  if FOnPlay=AValue then Exit;
  FOnPlay:=AValue;
end;

procedure TrAudioPlayer.SetOnStop(AValue: TStopEvent);
begin
  if FOnStop=AValue then Exit;
  FOnStop:=AValue;
end;

procedure TrAudioPlayer.InitializePlayers;
begin
  FDefaultPlayer := TDefaultAudioPlayer.Create;
  FDefaultPlayer.OnPlay := @PlayHandleEvent;
  FDefaultPlayer.OnStop := @StopHandleEvent;
  FDefaultPlayer.OnPause := @PauseHandleEvent;
  FDefaultPlayer.OnEnd := @EndHandleEvent;
  FDefaultPlayer.OnError := @ErrorHandleEvent;

  FHivelyPlayer := THivelyAudioPlayer.Create;
  FHivelyPlayer.OnPlay := @PlayHandleEvent;
  FHivelyPlayer.OnStop := @StopHandleEvent;
  FHivelyPlayer.OnPause := @PauseHandleEvent;
  FHivelyPlayer.OnEnd := @EndHandleEvent;
  FHivelyPlayer.OnError := @ErrorHandleEvent;

  FZxTunePlayer := TZxTuneAudioPlayer.Create;
  FZxTunePlayer.OnPlay := @PlayHandleEvent;
  FZxTunePlayer.OnStop := @StopHandleEvent;
  FZxTunePlayer.OnPause := @PauseHandleEvent;
  FZxTunePlayer.OnEnd := @EndHandleEvent;
  FZxTunePlayer.OnError := @ErrorHandleEvent;

  FOpenMptPlayer := TOpenMPTAudioPlayer.Create;
  FOpenMptPlayer.OnPlay := @PlayHandleEvent;
  FOpenMptPlayer.OnStop := @StopHandleEvent;
  FOpenMptPlayer.OnPause := @PauseHandleEvent;
  FOpenMptPlayer.OnEnd := @EndHandleEvent;
  FOpenMptPlayer.OnError := @ErrorHandleEvent;


  FXmpPlayer := TXmpAudioPlayer.Create;
  FXmpPlayer.OnPlay := @PlayHandleEvent;
  FXmpPlayer.OnStop := @StopHandleEvent;
  FXmpPlayer.OnPause := @PauseHandleEvent;
  FXmpPlayer.OnEnd := @EndHandleEvent;
  FXmpPlayer.OnError := @ErrorHandleEvent;

  FStSoundPlayer := TStSoundAudioPlayer.Create;
  FStSoundPlayer.OnPlay := @PlayHandleEvent;
  FStSoundPlayer.OnStop := @StopHandleEvent;
  FStSoundPlayer.OnPause := @PauseHandleEvent;
  FStSoundPlayer.OnEnd := @EndHandleEvent;
  FStSoundPlayer.OnError := @ErrorHandleEvent;

  FAsapPlayer := TAsapAudioPlayer.Create;
  FAsapPlayer.OnPlay := @PlayHandleEvent;
  FAsapPlayer.OnStop := @StopHandleEvent;
  FAsapPlayer.OnPause := @PauseHandleEvent;
  FAsapPlayer.OnEnd := @EndHandleEvent;
  FAsapPlayer.OnError := @ErrorHandleEvent;

  FGMEPlayer := TGMEAudioPlayer.Create;
  FGMEPlayer.OnPlay := @PlayHandleEvent;
  FGMEPlayer.OnStop := @StopHandleEvent;
  FGMEPlayer.OnPause := @PauseHandleEvent;
  FGMEPlayer.OnEnd := @EndHandleEvent;
  FGMEPlayer.OnError := @ErrorHandleEvent;

  FVGMPlayer := TVGMAudioPlayer.Create;
  FVGMPlayer.OnPlay := @PlayHandleEvent;
  FVGMPlayer.OnStop := @StopHandleEvent;
  FVGMPlayer.OnPause := @PauseHandleEvent;
  FVGMPlayer.OnEnd := @EndHandleEvent;
  FVGMPlayer.OnError := @ErrorHandleEvent;


  FCurrentPlayer := FDefaultPlayer; // По умолчанию
end;

procedure TrAudioPlayer.PlayHandleEvent(Sender: TObject; Track: Integer);
begin
  if Assigned(FOnPlay) then FOnPlay(Self, Track);
end;

procedure TrAudioPlayer.PauseHandleEvent(Sender: TObject; Track: Integer);
begin
  if Assigned(FOnPause) then FOnPause(Self, Track);
end;

procedure TrAudioPlayer.StopHandleEvent(Sender: TObject; Track: Integer);
begin
  if Assigned(FOnStop) then FOnStop(Self, Track);
end;

procedure TrAudioPlayer.EndHandleEvent(Sender: TObject; Track: Integer; FinishedNormally: Boolean);
begin
  if Assigned(FOnEnd) then FOnEnd(Self, Track, FinishedNormally);
end;

procedure TrAudioPlayer.ErrorHandleEvent(Sender: TObject; const Msg: string);
begin
  if Assigned(FOnError) then FOnError(Self, Msg);
end;

procedure TrAudioPlayer.SetVolume(Volume: Single);
begin
  FVolume := Volume;
end;

function TrAudioPlayer.GetVolume: Single;
begin
  Result := FVolume;
end;

procedure TrAudioPlayer.SetPosition(PositionMs: Integer);
begin
  if Assigned(FCurrentPlayer) then
    FCurrentPlayer.SetPosition(PositionMs);
end;

function TrAudioPlayer.GetPosition: Integer;
begin
  if Assigned(FCurrentPlayer) then
    Result := FCurrentPlayer.GetPosition
  else
    Result := 0;
end;

function TrAudioPlayer.GetDuration: Integer;
begin
  if Assigned(FCurrentPlayer) then
    Result := FCurrentPlayer.GetDuration
  else
    Result := 0;
end;

procedure TrAudioPlayer.SetLoopMode(Mode: Boolean);
begin
  FTrackLoop := Mode;
  if Assigned(FCurrentPlayer) then
    FCurrentPlayer.SetLoopMode(FTrackLoop);
end;

function TrAudioPlayer.GetLoopMode: Boolean;
begin
  if Assigned(FCurrentPlayer) then
  result := FCurrentPlayer.GetLoopMode else
    if Assigned(FOnError) then FOnError(Self,'Not loop mode set');
end;

function TrAudioPlayer.IsPlaying: Boolean;
begin
  Result := FIsPlaying;
end;

function TrAudioPlayer.IsPaused: Boolean;
begin
  Result := FIsPaused;
end;

function TrAudioPlayer.GetCurrentTrack: Integer;
begin
  //Result := FCurrentTrack;
  if Assigned(FCurrentPlayer) then
  Result := FCurrentPlayer.GetCurrentTrack else
end;

function TrAudioPlayer.GetCurrentFile: String;
begin
  Result := FCurrentFile;
end;

function TrAudioPlayer.GetTrackCount: Integer;
begin
  if Assigned(FCurrentPlayer) then
    Result := FCurrentPlayer.GetTrackCount else
     Result := 0;
// Result := FTrackCount;
end;

function TrAudioPlayer.GetEQBandsDecay: TEqBandsDecay;
begin
  if Assigned(FCurrentPlayer) then
    Result := FCurrentPlayer.GetEQBandsDecay
  else
    FillChar(Result, SizeOf(TEqBandsDecay), 0);
end;

function TrAudioPlayer.GetCurrentEngine: String;
begin
  case FPlayerEngine of
    ptUnknown:  Result := 'Unknown or unsupported audio format';
    ptDefault:  Result := 'Default audio player (raylib)';
    ptZxTune:   Result := 'ZXtune - ZX Spectrum chiptune player';
    ptHively:   Result := 'Hively - AHX/HVL tracker format player';
    ptOpenMPT:  Result := 'OpenMPT - Multi-platform tracker module player';
    ptXmp:      Result := 'XMP - Extended Module Player for tracked music';
    ptStSound:  Result := 'StSound - YM music chip emulator (Atari ST)';
    ptASAP:     Result := 'ASAP - Another Slight Atari Player';
    ptGME:      Result := 'Game Music Engine - Video game music emulator';
    ptVGM:      Result := 'VIDEO Game Music player';
  else
    Result := 'Unknown player engine';
  end;
end;


end.
