unit rStSoundAudioPlayer;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, libstsoundlibrary, libraudio, CommonTypes,
  rAudioIntf, contnrs, syncobjs, math;

type
  { TStSoundAudioPlayer }
  TStSoundAudioPlayer = class(TInterfacedObject, IMusicPlayer)
  private
    FStream: TAudioStream;
    FFilename: string;
    FFileData: Pointer;
    FFileSize: NativeUInt;
    FStSoundMusic: PYMMUSIC;
    FIsPaused: Boolean;
    FLoopMode: Boolean;
    FCurrentTrack: Integer;
    FPositionLock: TCriticalSection;
    FTrackEndTriggered: Boolean;
    FMusicInfo: TymMusicInfo;

    FEqBands: TEqBands;
    FEqBandsDecay: TEqBandsDecay;

    // Event handlers
    FOnPlay: TPlayEvent;
    FOnPause: TPauseEvent;
    FOnStop: TStopEvent;
    FOnEnd: TEndEvent;
    FOnError: TErrorEvent;

    class var FPlayers: TFPHashList;
    class var FCurrentPlayer: TStSoundAudioPlayer;

    class constructor ClassCreate;
    class destructor ClassDestroy;

    procedure InitializeAudioStream;
    procedure ResetPlayback;
    class procedure AudioCallback(bufferData: pointer; frames: LongWord); static; cdecl;
    procedure InternalStop(ClearTune: Boolean = True);
    procedure CheckError(Condition: Boolean; const Msg: string);
    procedure LoadModuleFile(const MusicFile: string);
    procedure FreeModuleData;

    procedure AnalyzeAudioBuffer(buffer: PByte; size: Integer);

    const
      DEFAULT_FREQ = 44100;
      DEFAULT_BITS = 16;
      DEFAULT_CHANNELS = 2;
      BUFFER_SIZE = 8192; // Размер буфера для рендеринга звука

  public
    constructor Create;
    destructor Destroy; override;

    // IMusicPlayer implementation
    procedure Play(const MusicFile: String; Track: Integer = 0);
    procedure Pause;
    procedure Resume;
    procedure Stop;
    procedure SetPosition(PositionMs: Integer);
    function GetPosition: Integer;
    function GetDuration: Integer;
    procedure SetLoopMode(Mode: Boolean);
    function GetLoopMode: Boolean;
    function IsPlaying: Boolean;
    function IsPaused: Boolean;
    function GetCurrentTrack: Integer;
    function GetCurrentFile: String;
    function GetTrackCount: Integer;

    // Вывод TTF
    function GetEQBandsDecay: TEqBandsDecay;

    // Event properties
    function GetOnPlay: TPlayEvent;
    function GetOnPause: TPauseEvent;
    function GetOnStop: TStopEvent;
    function GetOnEnd: TEndEvent;
    function GetOnError: TErrorEvent;
    procedure SetOnPlay(AEvent: TPlayEvent);
    procedure SetOnPause(AEvent: TPauseEvent);
    procedure SetOnStop(AEvent: TStopEvent);
    procedure SetOnEnd(AEvent: TEndEvent);
    procedure SetOnError(AEvent: TErrorEvent);

    property OnPlay: TPlayEvent read GetOnPlay write SetOnPlay;
    property OnPause: TPauseEvent read GetOnPause write SetOnPause;
    property OnStop: TStopEvent read GetOnStop write SetOnStop;
    property OnEnd: TEndEvent read GetOnEnd write SetOnEnd;
    property OnError: TErrorEvent read GetOnError write SetOnError;
  end;

implementation

{ TStSoundAudioPlayer }

class constructor TStSoundAudioPlayer.ClassCreate;
begin
  FPlayers := TFPHashList.Create;
  FCurrentPlayer := nil;
end;

class destructor TStSoundAudioPlayer.ClassDestroy;
begin
  FPlayers.Free;
end;

constructor TStSoundAudioPlayer.Create;
var
  i: integer;
begin
  inherited Create;
  FTrackEndTriggered := False;
  FIsPaused := False;
  FLoopMode := False;
  FCurrentTrack := 0;
  FPositionLock := TCriticalSection.Create;
  FFileData := nil;
  FFileSize := 0;
  FStSoundMusic := nil;

  for i := 0 to EQ_BANDS - 1 do
  begin
    FEqBands[i] := 0;
    FEqBandsDecay[i] := 0;
  end;

  InitializeAudioStream;
end;

destructor TStSoundAudioPlayer.Destroy;
begin
  InternalStop;
  FreeModuleData;
  FPositionLock.Free;
  inherited Destroy;
end;

procedure TStSoundAudioPlayer.InitializeAudioStream;
begin
  SetAudioStreamBufferSizeDefault(BUFFER_SIZE);
  FStream := LoadAudioStream(DEFAULT_FREQ, DEFAULT_BITS, DEFAULT_CHANNELS);
  if not IsAudioStreamReady(FStream) then
    raise Exception.Create('Failed to initialize audio stream');

  FPlayers.Add(IntToStr(PtrInt(Self)), Self);
  SetAudioStreamCallback(FStream, @AudioCallback);
end;

procedure TStSoundAudioPlayer.LoadModuleFile(const MusicFile: string);
var
  FileStream: TFileStream;
begin
  FreeModuleData;

  try
    FileStream := TFileStream.Create(MusicFile, fmOpenRead or fmShareDenyWrite);
    try
      FFileSize := FileStream.Size;
      GetMem(FFileData, FFileSize);
      FileStream.ReadBuffer(FFileData^, FFileSize);
    finally
      FileStream.Free;
    end;

    // Create StSound music object
    FStSoundMusic := ymMusicCreateWithRate(DEFAULT_FREQ);
    if FStSoundMusic = nil then
      raise Exception.Create('Failed to create StSound music object');

    // Load from memory
    if not ymMusicLoadMemory(FStSoundMusic, FFileData, FFileSize) then
      raise Exception.Create('Failed to load module: ' + string(ymMusicGetLastError(FStSoundMusic)));

    // Get music info
    ymMusicGetInfo(FStSoundMusic, @FMusicInfo);

    FFilename := MusicFile;
  except
    FreeModuleData;
    raise;
  end;
end;

procedure TStSoundAudioPlayer.FreeModuleData;
begin
  if FStSoundMusic <> nil then
  begin
    ymMusicStop(FStSoundMusic);
    ymMusicDestroy(FStSoundMusic);
    FStSoundMusic := nil;
  end;

  if FFileData <> nil then
  begin
    FreeMem(FFileData);
    FFileData := nil;
    FFileSize := 0;
  end;
end;

procedure TStSoundAudioPlayer.AnalyzeAudioBuffer(buffer: PByte; size: Integer);
var
  i, j, SampleCount: Integer;
  Sample: SmallInt;
  ChannelCount: Integer;
  SampleValue, Energy: Double;
  BandFactors: array[0..5] of Double = (0.1, 0.3, 0.5, 0.7, 0.9, 1.1);
begin
  if size = 0 then Exit;

  ChannelCount := DEFAULT_CHANNELS;
  SampleCount := size div (DEFAULT_BITS div 8) div ChannelCount;

  if SampleCount = 0 then Exit;

  // Анализируем каждый 10-й семпл для производительности
  for i := 0 to SampleCount - 1 do
  begin
    if i mod 10 <> 0 then Continue; // Пропускаем большинство семплов

    Sample := PSmallInt(buffer + i * ChannelCount * (DEFAULT_BITS div 8))^;
    SampleValue := Abs(Sample) / 32768.0;

    // Распределяем энергию по бэндам с разными коэффициентами
    for j := 0 to High(FEqBands) do
    begin
      // Каждый бэнд получает разную долю энергии
      Energy := SampleValue * BandFactors[j] * (1.2 - j * 0.15);
      FEqBands[j] := FEqBands[j] + Energy * Energy; // Квадрат для энергии
    end;
  end;

  // Обрабатываем бэнды
  for j := 0 to High(FEqBands) do
  begin
    // Нормализуем и извлекаем корень (RMS)
    FEqBands[j] := Sqrt(FEqBands[j] / (SampleCount / 10));

    // Логарифмическое масштабирование
    FEqBands[j] := Log10(FEqBands[j] * 50 + 1) * 0.8;

    // Применяем затухание с разной скоростью
    if FEqBands[j] > FEqBandsDecay[j] then
      FEqBandsDecay[j] := FEqBands[j]
    else
      FEqBandsDecay[j] := FEqBandsDecay[j] * (0.88 + j * 0.02);

    // Ограничения
    FEqBandsDecay[j] := Min(1.0, Max(0, FEqBandsDecay[j]));

    // Сброс для следующего буфера
    FEqBands[j] := 0;
  end;
end;

procedure TStSoundAudioPlayer.ResetPlayback;
begin
  if FStSoundMusic <> nil then
  begin
    ymMusicRestart(FStSoundMusic);
  end;
end;

class procedure TStSoundAudioPlayer.AudioCallback(bufferData: pointer; frames: LongWord); cdecl;
var
  SamplesRendered, i: Integer;
  Buffer: PSmallInt;
begin
  if FCurrentPlayer = nil then Exit;

  with FCurrentPlayer do
  begin
    FPositionLock.Enter;
    try
      if (FStSoundMusic = nil) or FIsPaused then
      begin
        FillChar(bufferData^, frames * DEFAULT_CHANNELS * (DEFAULT_BITS div 8), 0);
        Exit;
      end;

      // Рендерим звук в буфер
      Buffer := PSmallInt(bufferData);
      SamplesRendered := frames;

      // StSound рендерит моно звук, нужно преобразовать в стерео
      if not ymMusicCompute(FStSoundMusic, Buffer, frames) then
      begin
        FillChar(bufferData^, frames * DEFAULT_CHANNELS * (DEFAULT_BITS div 8), 0);
        Exit;
      end;

      // Преобразование моно в стерео
      for i := frames - 1 downto 0 do
      begin
        Buffer[i * 2] := Buffer[i];
        Buffer[i * 2 + 1] := Buffer[i];
      end;

      // TTF анализ
      AnalyzeAudioBuffer(bufferData, frames * DEFAULT_CHANNELS * (DEFAULT_BITS div 8));

      // Проверка окончания трека
      if ymMusicIsOver(FStSoundMusic) then
      begin
        if Assigned(FOnEnd) and (not FLoopMode) then
        begin
          FOnEnd(FCurrentPlayer, FCurrentTrack, true);
          FTrackEndTriggered := True;
        end;

        if FCurrentPlayer.GetLoopMode then
        begin
          ResetPlayback;
          FTrackEndTriggered := False;
        end;
      end;

    finally
      FPositionLock.Leave;
      if FTrackEndTriggered = True then InternalStop(True);
    end;
  end;
end;

procedure TStSoundAudioPlayer.CheckError(Condition: Boolean; const Msg: string);
begin
  if Condition and Assigned(FOnError) then
    FOnError(Self, Msg);
end;

procedure TStSoundAudioPlayer.InternalStop(ClearTune: Boolean);
begin
  FPositionLock.Enter;
  try
    if (FCurrentPlayer = Self) and IsAudioStreamPlaying(FStream) then
    begin
      if FCurrentPlayer = Self then
      begin
        StopAudioStream(FStream);
        FCurrentPlayer := nil;
      end;

      if ClearTune then
        FreeModuleData;

      FIsPaused := False;
      FTrackEndTriggered := False;

      if Assigned(FOnStop) then
        FOnStop(Self, FCurrentTrack);
    end;
  finally
    FPositionLock.Leave;
  end;
end;

procedure TStSoundAudioPlayer.Play(const MusicFile: String; Track: Integer);
begin
  if not FileExists(MusicFile) then
  begin
    CheckError(True, 'File not found: ' + MusicFile);
    Exit;
  end;

  FPositionLock.Enter;
  try
    // Stop current playback
    if IsAudioStreamPlaying(FStream) then InternalStop;

    // Load new module
    try
      LoadModuleFile(MusicFile);
      FCurrentTrack := Track;

      // Start playback
      FCurrentPlayer := Self;
      PlayAudioStream(FStream);
      FIsPaused := False;
      FTrackEndTriggered := False;

      if Assigned(FOnPlay) then
        FOnPlay(Self, FCurrentTrack);
    except
      on E: Exception do
      begin
        CheckError(True, 'Error loading module: ' + E.Message);
        InternalStop;
      end;
    end;
  finally
    FPositionLock.Leave;
  end;
end;

procedure TStSoundAudioPlayer.Pause;
begin
  FPositionLock.Enter;
  try
    if (FCurrentPlayer = Self) and not FIsPaused then
    begin
      PauseAudioStream(FStream);
      if FStSoundMusic <> nil then
        ymMusicPause(FStSoundMusic);
      FIsPaused := True;

      if Assigned(FOnPause) then
        FOnPause(Self, FCurrentTrack);
    end;
  finally
    FPositionLock.Leave;
  end;
end;

procedure TStSoundAudioPlayer.Resume;
begin
  FPositionLock.Enter;
  try
    if (FCurrentPlayer = Self) and FIsPaused then
    begin
      ResumeAudioStream(FStream);
      if FStSoundMusic <> nil then
        ymMusicPlay(FStSoundMusic);
      FIsPaused := False;

      if Assigned(FOnPlay) then
        FOnPlay(Self, FCurrentTrack);
    end;
  finally
    FPositionLock.Leave;
  end;
end;

procedure TStSoundAudioPlayer.Stop;
begin
  InternalStop;
end;

procedure TStSoundAudioPlayer.SetPosition(PositionMs: Integer);
begin
  FPositionLock.Enter;
  try
    if (FStSoundMusic <> nil) and ymMusicIsSeekable(FStSoundMusic) then
    begin
      ymMusicSeek(FStSoundMusic, PositionMs);
    end;
  finally
    FPositionLock.Leave;
  end;
end;

function TStSoundAudioPlayer.GetPosition: Integer;
begin
  Result := 0;
  FPositionLock.Enter;
  try
    if FStSoundMusic <> nil then
    begin
      Result := ymMusicGetPos(FStSoundMusic);
    end;
  finally
    FPositionLock.Leave;
  end;
end;

function TStSoundAudioPlayer.GetDuration: Integer;
begin
  Result := 0;
  FPositionLock.Enter;
  try
    if FStSoundMusic <> nil then
    begin
      Result := FMusicInfo.musicTimeInMs;
    end;
  finally
    FPositionLock.Leave;
  end;
end;

procedure TStSoundAudioPlayer.SetLoopMode(Mode: Boolean);
begin
  if FStSoundMusic <> nil then
  begin
    ymMusicSetLoopMode(FStSoundMusic, Mode);
    FLoopMode := Mode;
  end;
end;

function TStSoundAudioPlayer.GetLoopMode: Boolean;
begin
  Result := FLoopMode;
end;

function TStSoundAudioPlayer.IsPlaying: Boolean;
begin
  Result := (FCurrentPlayer = Self) and not FIsPaused and (FStSoundMusic <> nil);
end;

function TStSoundAudioPlayer.IsPaused: Boolean;
begin
  Result := FIsPaused;
end;

function TStSoundAudioPlayer.GetCurrentTrack: Integer;
begin
  Result := FCurrentTrack;
end;

function TStSoundAudioPlayer.GetCurrentFile: String;
begin
  Result := FFilename;
end;

function TStSoundAudioPlayer.GetTrackCount: Integer;
begin
  Result := 1; // StSound обычно обрабатывает однодорожечные модули
end;

function TStSoundAudioPlayer.GetEQBandsDecay: TEqBandsDecay;
begin
  Result := Self.FEqBandsDecay;
end;

// Event property getters/setters
function TStSoundAudioPlayer.GetOnPlay: TPlayEvent;
begin
  Result := FOnPlay;
end;

function TStSoundAudioPlayer.GetOnPause: TPauseEvent;
begin
  Result := FOnPause;
end;

function TStSoundAudioPlayer.GetOnStop: TStopEvent;
begin
  Result := FOnStop;
end;

function TStSoundAudioPlayer.GetOnEnd: TEndEvent;
begin
  Result := FOnEnd;
end;

function TStSoundAudioPlayer.GetOnError: TErrorEvent;
begin
  Result := FOnError;
end;

procedure TStSoundAudioPlayer.SetOnPlay(AEvent: TPlayEvent);
begin
  FOnPlay := AEvent;
end;

procedure TStSoundAudioPlayer.SetOnPause(AEvent: TPauseEvent);
begin
  FOnPause := AEvent;
end;

procedure TStSoundAudioPlayer.SetOnStop(AEvent: TStopEvent);
begin
  FOnStop := AEvent;
end;

procedure TStSoundAudioPlayer.SetOnEnd(AEvent: TEndEvent);
begin
  FOnEnd := AEvent;
end;

procedure TStSoundAudioPlayer.SetOnError(AEvent: TErrorEvent);
begin
  FOnError := AEvent;
end;

end.
