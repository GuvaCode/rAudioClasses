unit rDefaultAudioPlayer;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, libraudio,
  rAudioIntf, contnrs, syncobjs, Math;

type
  { TDefaultAudioPlayer }
  TDefaultAudioPlayer = class(TInterfacedObject, IMusicPlayer)
  private
    FStream: TAudioStream;
    FMusic: TMusic;
    FPaused: Boolean;
    FFileName: String;

    FTrackEndTrigger: Boolean;
    // Event fields
    FOnPlay: TPlayEvent;
    FOnPause: TPauseEvent;
    FOnStop: TStopEvent;
    FOnEnd: TEndEvent;
    FOnError: TErrorEvent;

    FEqBands: TEqBands;
    FEqBandsPeak: TEqBandsPeak;
    FEqBandsDecay: TEqBandsDecay;

    FPositionLock: TCriticalSection;

    class var FPlayers: TFPHashList;
    class var FCurrentPlayer: TDefaultAudioPlayer;

    class constructor ClassCreate;
    class destructor ClassDestroy;
    procedure InitializeAudioStream;
    class procedure AudioCallback({%H-}bufferData: pointer; {%H-}frames: LongWord); static; cdecl;
    class procedure AttachCallback(bufferData: pointer; frames: LongWord); static; cdecl;


    procedure CheckError(Success: Boolean; const Msg: string);
    procedure CheckTrackEnd;

    procedure AnalyzeAudioBuffer(buffer: PByte; size: Integer);
    const
      DEFAULT_FREQ = 44100;
      DEFAULT_BITS = 16;
      DEFAULT_CHANNELS = 2;
      BUFFER_SIZE = 8192; // Размер буфера для рендеринга звука

  public
    constructor Create;
    destructor Destroy; override;

    // Основные методы управления
    procedure Play(const MusicFile: String; Track: Integer = 1);

    procedure Pause;
    procedure Resume;
    procedure Stop;

    // Управление позицией
    procedure SetPosition(PositionMs: Integer);
    function GetPosition: Integer;
    function GetDuration: Integer;

    // Управление режимом повтора
    procedure SetLoopMode(Mode: Boolean);
    function GetLoopMode: Boolean;

    // Состояние плеера
    function IsPlaying: Boolean;
    function IsPaused: Boolean;

    // Информация о треке
    function GetCurrentTrack: Integer;
    function GetCurrentFile: String;
    function GetTrackCount: Integer;

    // Вывод TTF
    function GetEQBandsDecay: TEqBandsDecay;

    // События
    function GetOnEnd: TEndEvent;
    function GetOnError: TErrorEvent;
    function GetOnPause: TPauseEvent;
    function GetOnPlay: TPlayEvent;
    function GetOnStop: TStopEvent;

    procedure SetOnEnd(AEvent: TEndEvent);
    procedure SetOnError(AEvent: TErrorEvent);
    procedure SetOnPause(AEvent: TPauseEvent);
    procedure SetOnPlay(AEvent: TPlayEvent);
    procedure SetOnStop(AEvent: TStopEvent);

    property OnPlay: TPlayEvent read FOnPlay write FOnPlay;
    property OnPause: TPauseEvent read FOnPause write FOnPause;
    property OnStop: TStopEvent read FOnStop write FOnStop;
    property OnEnd: TEndEvent read FOnEnd write FOnEnd;
    property OnError: TErrorEvent read FOnError write FOnError;
  end;

implementation

{ TDefaultAudioPlayer }

class constructor TDefaultAudioPlayer.ClassCreate;
begin
  FPlayers := TFPHashList.Create;
  FCurrentPlayer := nil;
end;

class destructor TDefaultAudioPlayer.ClassDestroy;
begin
  FPlayers.Free;
end;

procedure TDefaultAudioPlayer.CheckError(Success: Boolean; const Msg: string);
begin
  if not Success and Assigned(FOnError) then
    FOnError(Self, Msg);
end;

procedure TDefaultAudioPlayer.CheckTrackEnd;
begin
  if not Assigned(FCurrentPlayer) then Exit;
  FPaused := False;
  StopAudioStream(FStream);
  if Assigned(FOnEnd) then FOnEnd(Self, GetCurrentTrack, True);
end;

procedure TDefaultAudioPlayer.AnalyzeAudioBuffer(buffer: PByte; size: Integer);
{$I BandAnalyzer.inc}
end;


procedure TDefaultAudioPlayer.InitializeAudioStream;
begin
  SetAudioStreamBufferSizeDefault(8192);
  FStream := LoadAudioStream(44100, 16, 2);
  if IsAudioStreamReady(FStream) then
  begin
    FPlayers.Add(IntToStr(PtrInt(Self)), Self);
    SetAudioStreamCallback(FStream, @AudioCallback);
        AttachAudioMixedProcessor(@AttachCallback);
    if Assigned(FOnError) then
    FOnError(Self, 'initialize audio stream');
  end
  else if Assigned(FOnError) then
    FOnError(Self, 'Failed to initialize audio stream');
end;

class procedure TDefaultAudioPlayer.AudioCallback(bufferData: pointer; frames: LongWord); cdecl;
begin
  if Assigned(FCurrentPlayer) then
  begin
    FCurrentPlayer.FPositionLock.Enter;
    try
      UpdateMusicStream(FCurrentPlayer.FMusic);

      if (not IsMusicStreamPlaying(FCurrentPlayer.FMusic)) and
         (not FCurrentPlayer.FPaused) and
         (not FCurrentPlayer.FMusic.looping) then
        FCurrentPlayer.CheckTrackEnd;
    finally
      FCurrentPlayer.FPositionLock.Leave;
    end;
  end;
end;

// В реализации
class procedure TDefaultAudioPlayer.AttachCallback(bufferData: pointer; frames: LongWord); cdecl;
begin
  if Assigned(FCurrentPlayer) then
  begin
    FCurrentPlayer.FPositionLock.Enter;
    try
      // TTF анализ буфера
      FCurrentPlayer.AnalyzeAudioBuffer(PByte(bufferData), frames);
    finally
      FCurrentPlayer.FPositionLock.Leave;
    end;
  end;
end;



constructor TDefaultAudioPlayer.Create;
var
  i: integer;
begin
  inherited Create;

  FPositionLock := TCriticalSection.Create;

  InitializeAudioStream;
  FPaused := False;
  FCurrentPlayer := Self;

  for i := 0 to EQ_BANDS - 1 do
  begin
    FeqBands[i] := 0;
    FeqBandsPeak[i] := 0;
    FeqBandsDecay[i] := 0;
  end;
end;

destructor TDefaultAudioPlayer.Destroy;
begin
  Stop;
  FPlayers.Remove(Self);
  if IsMusicReady(FMusic) then
    UnloadMusicStream(FMusic);
  if IsAudioStreamReady(FStream) then
    UnloadAudioStream(FStream);
  FPositionLock.Free;
  inherited Destroy;
end;

procedure TDefaultAudioPlayer.Play(const MusicFile: String; Track: Integer);
begin
  FPositionLock.Enter;
  try
    if not FileExists(MusicFile) then
    begin
      if Assigned(FOnError) then
        FOnError(Self, 'File not found: ' + MusicFile);
      Exit;
    end;

    Stop; // Остановить текущее воспроизведение

    FMusic := LoadMusicStream(PChar(MusicFile));
    if not IsMusicReady(FMusic) then
    begin
      if Assigned(FOnError) then
        FOnError(Self, 'Failed to load music: ' + MusicFile);
      Exit;
    end;

    FFileName := MusicFile;
    FCurrentPlayer := Self;

    PlayMusicStream(FMusic);
    FPaused := False;
    FMusic.looping := True;
    FTrackEndTrigger := False;

    if Assigned(FOnPlay) then
      FOnPlay(Self, Track);

    PlayAudioStream(FStream);
  finally
    FPositionLock.Leave;
  end;
end;


procedure TDefaultAudioPlayer.Pause;
begin
  if IsMusicStreamPlaying(FMusic) then
  begin
    PauseMusicStream(FMusic);
    FPaused := True;
    if Assigned(FOnPause) then
      FOnPause(Self, GetCurrentTrack);
  end;
end;

procedure TDefaultAudioPlayer.Resume;
begin
  if FPaused and IsMusicReady(FMusic) then
  begin
    ResumeMusicStream(FMusic);
    FPaused := False;
  end;
end;

procedure TDefaultAudioPlayer.Stop;
begin
  FPositionLock.Enter;
  try
    if IsMusicStreamPlaying(FMusic) then
    begin
      StopMusicStream(FMusic);
      StopAudioStream(FStream);
      if Assigned(FOnStop) then
        FOnStop(Self, GetCurrentTrack);
    end;
    FPaused := False;
    FCurrentPlayer := nil; // Сброс текущего плеера
  finally
    FPositionLock.Leave;
  end;
end;

procedure TDefaultAudioPlayer.SetPosition(PositionMs: Integer);
var
  Seconds: Single;
begin
  StopAudioStream(FStream);
  if IsMusicReady(FMusic) then
  begin
    Seconds := PositionMs / 1000;
    if Seconds < 0 then Seconds := 0;
    if Seconds > GetMusicTimeLength(FMusic) then
      Seconds := GetMusicTimeLength(FMusic);
    SeekMusicStream(FMusic, Seconds);
  end;
  PlayAudioStream(FStream);

end;

function TDefaultAudioPlayer.GetPosition: Integer;
begin
  Result := 0;
  if IsMusicReady(FMusic) then
    Result := Trunc(GetMusicTimePlayed(FMusic) * 1000);
end;

function TDefaultAudioPlayer.GetDuration: Integer;
begin
  Result := 0;
  if IsMusicReady(FMusic) then
    Result := Trunc(GetMusicTimeLength(FMusic) * 1000);
end;

procedure TDefaultAudioPlayer.SetLoopMode(Mode: Boolean);
begin
  if IsMusicReady(FMusic) then
  begin
    FMusic.looping:= Mode;
    FPaused := Mode;
  end;
end;

function TDefaultAudioPlayer.GetLoopMode: Boolean;
begin
  if IsMusicReady(FMusic) then
  Result := FMusic.looping;
end;

function TDefaultAudioPlayer.IsPlaying: Boolean;
begin
  Result := IsMusicReady(FMusic) and IsMusicStreamPlaying(FMusic) and not FPaused;
end;

function TDefaultAudioPlayer.IsPaused: Boolean;
begin
  Result := FPaused;
end;

function TDefaultAudioPlayer.GetCurrentTrack: Integer;
begin
  Result := 0;
end;

function TDefaultAudioPlayer.GetCurrentFile: String;
begin
  Result := FFileName;
end;

function TDefaultAudioPlayer.GetTrackCount: Integer;
begin
  Result := 0;
end;

function TDefaultAudioPlayer.GetEQBandsDecay: TEqBandsDecay;
begin
  Result := FEqBandsDecay;
end;


function TDefaultAudioPlayer.GetOnEnd: TEndEvent;
begin
  Result := FOnEnd;
end;

function TDefaultAudioPlayer.GetOnError: TErrorEvent;
begin
  Result := FOnError;
end;

function TDefaultAudioPlayer.GetOnPause: TPauseEvent;
begin
  Result := FOnPause;
end;

function TDefaultAudioPlayer.GetOnPlay: TPlayEvent;
begin
  Result := FOnPlay;
end;

function TDefaultAudioPlayer.GetOnStop: TStopEvent;
begin
  Result := FOnStop;
end;

procedure TDefaultAudioPlayer.SetOnEnd(AEvent: TEndEvent);
begin
  FOnEnd := AEvent;
end;

procedure TDefaultAudioPlayer.SetOnError(AEvent: TErrorEvent);
begin
  FOnError := AEvent;
end;

procedure TDefaultAudioPlayer.SetOnPause(AEvent: TPauseEvent);
begin
  FOnPause := AEvent;
end;

procedure TDefaultAudioPlayer.SetOnPlay(AEvent: TPlayEvent);
begin
  FOnPlay := AEvent;
end;

procedure TDefaultAudioPlayer.SetOnStop(AEvent: TStopEvent);
begin
  FOnStop := AEvent;
end;

end.
